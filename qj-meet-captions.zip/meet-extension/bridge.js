// Runs on the Closer Software page. Hands caption messages from the extension to the page.
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.source === 'qj-meet-captions') window.postMessage(msg, window.location.origin);
});
// Let the page know the extension is installed.
const hello = () => window.postMessage({ source: 'qj-meet-captions', type: 'hello', version: chrome.runtime.getManifest().version }, window.location.origin);
hello();
window.addEventListener('DOMContentLoaded', hello);
window.addEventListener('message', (e) => { if (e.source === window && e.data && e.data.source === 'qj-closer-page' && e.data.type === 'ping') hello(); });
