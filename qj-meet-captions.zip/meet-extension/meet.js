// Runs inside Google Meet. Reads Meet's own live captions (turn them on with the CC button or "c")
// and sends each caption line, labelled by speaker, to the Closer Software tab.
(() => {
  const SEND = (msg) => {
    msg.source = 'qj-meet-captions';
    try { chrome.runtime.sendMessage(msg); } catch (e) { /* extension reloaded; ignore */ }
  };

  // Meet renders captions in a region labelled "Captions". Class names change often, so we only rely on
  // that label and on structure: each caption block = speaker name line + caption text.
  function findRegion() {
    return document.querySelector('[role="region"][aria-label*="aption" i]')
      || document.querySelector('[aria-label="Captions"]')
      || document.querySelector('[jsname="dsyhDe"]');
  }

  function blocksOf(region) {
    // A caption block is a child that contains both a name and text. Walk down single-child wrappers.
    let el = region;
    while (el && el.children.length === 1) el = el.children[0];
    return el ? [...el.children].filter((c) => (c.innerText || '').trim()) : [];
  }

  function parseBlock(block) {
    const lines = (block.innerText || '').split('\n').map((s) => s.trim()).filter(Boolean);
    if (lines.length < 2) return null;
    const name = lines[0];
    const text = lines.slice(1).join(' ').trim();
    if (!text || name.length > 60) return null;
    return { name, text };
  }

  const ids = new WeakMap();
  let nextId = 1;
  const seen = new Map(); // id -> { who, text, changedAt, final, node }
  let lastStatus = '';

  function status(s) { if (s !== lastStatus) { lastStatus = s; SEND({ type: 'status', status: s }); } }

  function tick() {
    const region = findRegion();
    if (!region) { status(document.querySelector('[data-call-ended], [jsname="r4nke"]') ? 'not_in_call' : 'captions_off'); finalizeAll(); return; }
    status('listening');
    const now = Date.now();
    const blocks = blocksOf(region);
    const live = new Set();
    blocks.forEach((b, i) => {
      const p = parseBlock(b);
      if (!p) return;
      if (!ids.has(b)) ids.set(b, 'm' + (nextId++));
      const id = ids.get(b);
      live.add(id);
      const who = /^you$/i.test(p.name) ? 'You' : 'Prospect';
      const prev = seen.get(id);
      if (!prev || prev.text !== p.text) {
        seen.set(id, { who, name: p.name, text: p.text, changedAt: now, final: false });
        SEND({ type: 'caption', id, who, name: p.name, text: p.text, final: false });
      } else if (!prev.final && (now - prev.changedAt > 1200 || i < blocks.length - 1)) {
        prev.final = true;
        SEND({ type: 'caption', id, who, name: prev.name, text: prev.text, final: true });
      }
    });
    for (const [id, v] of seen) {
      if (!live.has(id)) {
        if (!v.final) SEND({ type: 'caption', id, who: v.who, name: v.name, text: v.text, final: true });
        seen.delete(id);
      }
    }
  }

  function finalizeAll() {
    for (const [id, v] of seen) { if (!v.final) SEND({ type: 'caption', id, who: v.who, name: v.name, text: v.text, final: true }); }
    seen.clear();
  }

  setInterval(tick, 350);
})();
