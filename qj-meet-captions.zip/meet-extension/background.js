// Relays caption messages from the Meet tab to any open Closer Software tab.
const TARGETS = ['https://dashboard.qualityjobs.com.au/*', 'http://localhost:8791/*'];

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || msg.source !== 'qj-meet-captions') return;
  if (!sender.tab || !/^https:\/\/meet\.google\.com\//.test(sender.tab.url || '')) return;
  chrome.tabs.query({ url: TARGETS }, (tabs) => {
    for (const t of tabs) chrome.tabs.sendMessage(t.id, msg).catch(() => {});
  });
});
